﻿/*
 * Created by SharpDevelop.
 * User: jenni
 * Date: 19/10/2025
 * Time: 20:41
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace SistemaQuiz
{
	/// <summary>
	/// Description of ResumosINForm.
	/// </summary>
	public partial class ResumosINForm : Form
	{
		public ResumosINForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
	}
}
