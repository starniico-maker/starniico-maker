﻿/*
 * Created by SharpDevelop.
 * User: jenni
 * Date: 29/10/2025
 * Time: 15:17
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace SistemaQuiz
{
	partial class Resumo1BIForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Resumo1BIForm));
			this.panel2 = new System.Windows.Forms.Panel();
			this.btnProxima = new System.Windows.Forms.Button();
			this.panel5 = new System.Windows.Forms.Panel();
			this.label3 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.panel10 = new System.Windows.Forms.Panel();
			this.label1 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.panel11 = new System.Windows.Forms.Panel();
			this.label23 = new System.Windows.Forms.Label();
			this.panel12 = new System.Windows.Forms.Panel();
			this.label25 = new System.Windows.Forms.Label();
			this.label26 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.lblAssinaturas = new System.Windows.Forms.Label();
			this.lblPontuacao = new System.Windows.Forms.Label();
			this.lblHome = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.lblMaterias = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.lblInfoUSP = new System.Windows.Forms.Label();
			this.lblCursosUSP = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.lblInfoUnesp = new System.Windows.Forms.Label();
			this.lblCursosUnesp = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.lblInfoUnicamp = new System.Windows.Forms.Label();
			this.lblCursosUnicamp = new System.Windows.Forms.Label();
			this.lblFatec = new System.Windows.Forms.Label();
			this.lblInfoFatec = new System.Windows.Forms.Label();
			this.lblCursosFatec = new System.Windows.Forms.Label();
			this.lblVestibulares = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.panel2.SuspendLayout();
			this.panel5.SuspendLayout();
			this.panel10.SuspendLayout();
			this.panel11.SuspendLayout();
			this.panel12.SuspendLayout();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			this.SuspendLayout();
			// 
			// panel2
			// 
			this.panel2.AutoScroll = true;
			this.panel2.AutoScrollMinSize = new System.Drawing.Size(0, 900);
			this.panel2.Controls.Add(this.btnProxima);
			this.panel2.Controls.Add(this.panel5);
			this.panel2.Controls.Add(this.panel10);
			this.panel2.Controls.Add(this.panel11);
			this.panel2.Controls.Add(this.panel12);
			this.panel2.Controls.Add(this.label4);
			this.panel2.Controls.Add(this.label2);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel2.Location = new System.Drawing.Point(260, 0);
			this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(1056, 788);
			this.panel2.TabIndex = 63;
			// 
			// btnProxima
			// 
			this.btnProxima.BackColor = System.Drawing.Color.Maroon;
			this.btnProxima.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnProxima.ForeColor = System.Drawing.Color.White;
			this.btnProxima.Location = new System.Drawing.Point(360, 875);
			this.btnProxima.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnProxima.Name = "btnProxima";
			this.btnProxima.Size = new System.Drawing.Size(309, 49);
			this.btnProxima.TabIndex = 118;
			this.btnProxima.Text = "FINALIZAR RESUMO";
			this.btnProxima.UseVisualStyleBackColor = false;
			this.btnProxima.Click += new System.EventHandler(this.BtnProximaClick);
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.Color.LightGray;
			this.panel5.Controls.Add(this.label3);
			this.panel5.Controls.Add(this.label6);
			this.panel5.Controls.Add(this.label9);
			this.panel5.Location = new System.Drawing.Point(33, 623);
			this.panel5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(984, 226);
			this.panel5.TabIndex = 116;
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.Black;
			this.label3.Location = new System.Drawing.Point(18, 63);
			this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(948, 141);
			this.label3.TabIndex = 49;
			this.label3.Text = resources.GetString("label3.Text");
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.Black;
			this.label6.Location = new System.Drawing.Point(18, 18);
			this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(614, 45);
			this.label6.TabIndex = 47;
			this.label6.Text = "Ciclo do Nitrogênio";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label9
			// 
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label9.ForeColor = System.Drawing.Color.Black;
			this.label9.Location = new System.Drawing.Point(18, 63);
			this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(962, 158);
			this.label9.TabIndex = 45;
			// 
			// panel10
			// 
			this.panel10.BackColor = System.Drawing.Color.LightGray;
			this.panel10.Controls.Add(this.label1);
			this.panel10.Controls.Add(this.label21);
			this.panel10.Controls.Add(this.label22);
			this.panel10.Location = new System.Drawing.Point(33, 372);
			this.panel10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(984, 226);
			this.panel10.TabIndex = 115;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Black;
			this.label1.Location = new System.Drawing.Point(18, 72);
			this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(948, 141);
			this.label1.TabIndex = 48;
			this.label1.Text = resources.GetString("label1.Text");
			// 
			// label21
			// 
			this.label21.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label21.ForeColor = System.Drawing.Color.Black;
			this.label21.Location = new System.Drawing.Point(18, 18);
			this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(614, 45);
			this.label21.TabIndex = 47;
			this.label21.Text = "Ciclo do Carbono";
			this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label22
			// 
			this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label22.ForeColor = System.Drawing.Color.Black;
			this.label22.Location = new System.Drawing.Point(18, 63);
			this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(918, 129);
			this.label22.TabIndex = 45;
			// 
			// panel11
			// 
			this.panel11.BackColor = System.Drawing.Color.DarkRed;
			this.panel11.Controls.Add(this.label23);
			this.panel11.Location = new System.Drawing.Point(33, 103);
			this.panel11.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel11.Name = "panel11";
			this.panel11.Size = new System.Drawing.Size(984, 77);
			this.panel11.TabIndex = 117;
			// 
			// label23
			// 
			this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label23.ForeColor = System.Drawing.Color.White;
			this.label23.Location = new System.Drawing.Point(18, 14);
			this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(962, 68);
			this.label23.TabIndex = 45;
			this.label23.Text = "O que são: Processos naturais que reciclam elementos essenciais entre os componen" +
			"tes vivos (bio) e não vivos (geo) da Terra.";
			// 
			// panel12
			// 
			this.panel12.BackColor = System.Drawing.Color.LightGray;
			this.panel12.Controls.Add(this.label25);
			this.panel12.Controls.Add(this.label26);
			this.panel12.Location = new System.Drawing.Point(33, 203);
			this.panel12.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel12.Name = "panel12";
			this.panel12.Size = new System.Drawing.Size(984, 143);
			this.panel12.TabIndex = 114;
			// 
			// label25
			// 
			this.label25.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label25.ForeColor = System.Drawing.Color.Black;
			this.label25.Location = new System.Drawing.Point(18, 18);
			this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(614, 45);
			this.label25.TabIndex = 47;
			this.label25.Text = "Ciclo da Água";
			this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label26
			// 
			this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label26.ForeColor = System.Drawing.Color.Black;
			this.label26.Location = new System.Drawing.Point(18, 63);
			this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(962, 58);
			this.label26.TabIndex = 45;
			this.label26.Text = "• Processos Principais: Evaporação, Transpiração, Precipitação, Infiltração e Esc" +
			"oamento.\r\n• Importância: Distribui a água doce pelo planeta.";
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(30, 54);
			this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(992, 45);
			this.label4.TabIndex = 68;
			this.label4.Text = "CICLOS BIOGEOQUÍMICOS";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(30, 11);
			this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(982, 60);
			this.label2.TabIndex = 67;
			this.label2.Text = "RESUMO ";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.DarkRed;
			this.panel1.Controls.Add(this.pictureBox2);
			this.panel1.Controls.Add(this.lblAssinaturas);
			this.panel1.Controls.Add(this.lblPontuacao);
			this.panel1.Controls.Add(this.lblHome);
			this.panel1.Controls.Add(this.label24);
			this.panel1.Controls.Add(this.label20);
			this.panel1.Controls.Add(this.lblMaterias);
			this.panel1.Controls.Add(this.label17);
			this.panel1.Controls.Add(this.lblInfoUSP);
			this.panel1.Controls.Add(this.lblCursosUSP);
			this.panel1.Controls.Add(this.label14);
			this.panel1.Controls.Add(this.lblInfoUnesp);
			this.panel1.Controls.Add(this.lblCursosUnesp);
			this.panel1.Controls.Add(this.label11);
			this.panel1.Controls.Add(this.lblInfoUnicamp);
			this.panel1.Controls.Add(this.lblCursosUnicamp);
			this.panel1.Controls.Add(this.lblFatec);
			this.panel1.Controls.Add(this.lblInfoFatec);
			this.panel1.Controls.Add(this.lblCursosFatec);
			this.panel1.Controls.Add(this.lblVestibulares);
			this.panel1.Controls.Add(this.label7);
			this.panel1.ForeColor = System.Drawing.Color.Transparent;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(254, 788);
			this.panel1.TabIndex = 62;
			// 
			// pictureBox2
			// 
			this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Default;
			this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
			this.pictureBox2.Location = new System.Drawing.Point(38, 0);
			this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(152, 98);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox2.TabIndex = 34;
			this.pictureBox2.TabStop = false;
			// 
			// lblAssinaturas
			// 
			this.lblAssinaturas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAssinaturas.Location = new System.Drawing.Point(20, 169);
			this.lblAssinaturas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblAssinaturas.Name = "lblAssinaturas";
			this.lblAssinaturas.Size = new System.Drawing.Size(196, 35);
			this.lblAssinaturas.TabIndex = 32;
			this.lblAssinaturas.Text = "Assinaturas";
			this.lblAssinaturas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblAssinaturas.Click += new System.EventHandler(this.LblAssinaturasClick);
			// 
			// lblPontuacao
			// 
			this.lblPontuacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPontuacao.Location = new System.Drawing.Point(20, 134);
			this.lblPontuacao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblPontuacao.Name = "lblPontuacao";
			this.lblPontuacao.Size = new System.Drawing.Size(196, 35);
			this.lblPontuacao.TabIndex = 31;
			this.lblPontuacao.Text = "Pontuação";
			this.lblPontuacao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblPontuacao.Click += new System.EventHandler(this.LblPontuacaoClick);
			// 
			// lblHome
			// 
			this.lblHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblHome.Location = new System.Drawing.Point(38, 98);
			this.lblHome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblHome.Name = "lblHome";
			this.lblHome.Size = new System.Drawing.Size(178, 35);
			this.lblHome.TabIndex = 24;
			this.lblHome.Text = "Tela Inicial";
			this.lblHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblHome.Click += new System.EventHandler(this.LblHomeClick);
			// 
			// label24
			// 
			this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label24.Location = new System.Drawing.Point(4, 97);
			this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(44, 35);
			this.label24.TabIndex = 23;
			this.label24.Text = "➔ ";
			this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label20
			// 
			this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label20.Location = new System.Drawing.Point(20, 252);
			this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(218, 35);
			this.label20.TabIndex = 29;
			this.label20.Text = "Provão Paulista";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblMaterias
			// 
			this.lblMaterias.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblMaterias.Location = new System.Drawing.Point(20, 283);
			this.lblMaterias.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblMaterias.Name = "lblMaterias";
			this.lblMaterias.Size = new System.Drawing.Size(160, 35);
			this.lblMaterias.TabIndex = 30;
			this.lblMaterias.Text = "• Matérias";
			this.lblMaterias.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblMaterias.Click += new System.EventHandler(this.LblMateriasClick);
			// 
			// label17
			// 
			this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label17.Location = new System.Drawing.Point(20, 331);
			this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(160, 35);
			this.label17.TabIndex = 26;
			this.label17.Text = "USP";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblInfoUSP
			// 
			this.lblInfoUSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoUSP.Location = new System.Drawing.Point(20, 366);
			this.lblInfoUSP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblInfoUSP.Name = "lblInfoUSP";
			this.lblInfoUSP.Size = new System.Drawing.Size(218, 35);
			this.lblInfoUSP.TabIndex = 27;
			this.lblInfoUSP.Text = "• Informações";
			this.lblInfoUSP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoUSP.Click += new System.EventHandler(this.LblInfoUSPClick);
			// 
			// lblCursosUSP
			// 
			this.lblCursosUSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosUSP.Location = new System.Drawing.Point(20, 391);
			this.lblCursosUSP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblCursosUSP.Name = "lblCursosUSP";
			this.lblCursosUSP.Size = new System.Drawing.Size(160, 37);
			this.lblCursosUSP.TabIndex = 28;
			this.lblCursosUSP.Text = "• Cursos";
			this.lblCursosUSP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosUSP.Click += new System.EventHandler(this.LblCursosUSPClick);
			// 
			// label14
			// 
			this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.Location = new System.Drawing.Point(20, 440);
			this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(160, 35);
			this.label14.TabIndex = 23;
			this.label14.Text = "Unesp";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblInfoUnesp
			// 
			this.lblInfoUnesp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoUnesp.Location = new System.Drawing.Point(20, 472);
			this.lblInfoUnesp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblInfoUnesp.Name = "lblInfoUnesp";
			this.lblInfoUnesp.Size = new System.Drawing.Size(160, 35);
			this.lblInfoUnesp.TabIndex = 24;
			this.lblInfoUnesp.Text = "• Informações";
			this.lblInfoUnesp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoUnesp.Click += new System.EventHandler(this.LblInfoUnespClick);
			// 
			// lblCursosUnesp
			// 
			this.lblCursosUnesp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosUnesp.Location = new System.Drawing.Point(20, 497);
			this.lblCursosUnesp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblCursosUnesp.Name = "lblCursosUnesp";
			this.lblCursosUnesp.Size = new System.Drawing.Size(160, 37);
			this.lblCursosUnesp.TabIndex = 25;
			this.lblCursosUnesp.Text = "• Cursos";
			this.lblCursosUnesp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosUnesp.Click += new System.EventHandler(this.LblCursosUnespClick);
			// 
			// label11
			// 
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.Location = new System.Drawing.Point(20, 551);
			this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(160, 35);
			this.label11.TabIndex = 20;
			this.label11.Text = "Unicamp";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblInfoUnicamp
			// 
			this.lblInfoUnicamp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoUnicamp.Location = new System.Drawing.Point(20, 582);
			this.lblInfoUnicamp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblInfoUnicamp.Name = "lblInfoUnicamp";
			this.lblInfoUnicamp.Size = new System.Drawing.Size(160, 35);
			this.lblInfoUnicamp.TabIndex = 21;
			this.lblInfoUnicamp.Text = "• Informações";
			this.lblInfoUnicamp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoUnicamp.Click += new System.EventHandler(this.LblInfoUnicampClick);
			// 
			// lblCursosUnicamp
			// 
			this.lblCursosUnicamp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosUnicamp.Location = new System.Drawing.Point(20, 606);
			this.lblCursosUnicamp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblCursosUnicamp.Name = "lblCursosUnicamp";
			this.lblCursosUnicamp.Size = new System.Drawing.Size(160, 37);
			this.lblCursosUnicamp.TabIndex = 22;
			this.lblCursosUnicamp.Text = "• Cursos";
			this.lblCursosUnicamp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosUnicamp.Click += new System.EventHandler(this.LblCursosUnicampClick);
			// 
			// lblFatec
			// 
			this.lblFatec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFatec.Location = new System.Drawing.Point(20, 657);
			this.lblFatec.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblFatec.Name = "lblFatec";
			this.lblFatec.Size = new System.Drawing.Size(160, 35);
			this.lblFatec.TabIndex = 17;
			this.lblFatec.Text = "Fatec";
			this.lblFatec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblInfoFatec
			// 
			this.lblInfoFatec.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoFatec.Location = new System.Drawing.Point(20, 688);
			this.lblInfoFatec.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblInfoFatec.Name = "lblInfoFatec";
			this.lblInfoFatec.Size = new System.Drawing.Size(160, 35);
			this.lblInfoFatec.TabIndex = 18;
			this.lblInfoFatec.Text = "• Informações";
			this.lblInfoFatec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoFatec.Click += new System.EventHandler(this.LblInfoFatecClick);
			// 
			// lblCursosFatec
			// 
			this.lblCursosFatec.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosFatec.Location = new System.Drawing.Point(20, 712);
			this.lblCursosFatec.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblCursosFatec.Name = "lblCursosFatec";
			this.lblCursosFatec.Size = new System.Drawing.Size(160, 37);
			this.lblCursosFatec.TabIndex = 19;
			this.lblCursosFatec.Text = "• Cursos";
			this.lblCursosFatec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosFatec.Click += new System.EventHandler(this.LblCursosFatecClick);
			// 
			// lblVestibulares
			// 
			this.lblVestibulares.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblVestibulares.Location = new System.Drawing.Point(38, 215);
			this.lblVestibulares.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblVestibulares.Name = "lblVestibulares";
			this.lblVestibulares.Size = new System.Drawing.Size(178, 35);
			this.lblVestibulares.TabIndex = 7;
			this.lblVestibulares.Text = "Vestibulares";
			this.lblVestibulares.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.Location = new System.Drawing.Point(4, 214);
			this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(44, 35);
			this.label7.TabIndex = 6;
			this.label7.Text = "➔ ";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// Resumo1BIForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1316, 788);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.Name = "Resumo1BIForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Resumo1BIForm";
			this.panel2.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.panel10.ResumeLayout(false);
			this.panel11.ResumeLayout(false);
			this.panel12.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label lblVestibulares;
		private System.Windows.Forms.Label lblCursosFatec;
		private System.Windows.Forms.Label lblInfoFatec;
		private System.Windows.Forms.Label lblFatec;
		private System.Windows.Forms.Label lblCursosUnicamp;
		private System.Windows.Forms.Label lblInfoUnicamp;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label lblCursosUnesp;
		private System.Windows.Forms.Label lblInfoUnesp;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label lblCursosUSP;
		private System.Windows.Forms.Label lblInfoUSP;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label lblMaterias;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Label lblHome;
		private System.Windows.Forms.Label lblPontuacao;
		private System.Windows.Forms.Label lblAssinaturas;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.Panel panel12;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Panel panel11;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Panel panel10;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Button btnProxima;
		private System.Windows.Forms.Panel panel2;
	}
}
