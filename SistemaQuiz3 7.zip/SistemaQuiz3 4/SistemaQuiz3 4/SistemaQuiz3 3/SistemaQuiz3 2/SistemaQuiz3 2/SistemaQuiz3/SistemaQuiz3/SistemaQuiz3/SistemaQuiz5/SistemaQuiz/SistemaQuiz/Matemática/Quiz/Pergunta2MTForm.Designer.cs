﻿/*
 * Created by SharpDevelop.
 * User: jenni
 * Date: 31/10/2025
 * Time: 13:43
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace SistemaQuiz
{
	partial class Pergunta2MTForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label lblVestibulares;
		private System.Windows.Forms.Label lblCursosFatec;
		private System.Windows.Forms.Label lblInfoFatec;
		private System.Windows.Forms.Label lblFatec;
		private System.Windows.Forms.Label lblCursosUnicamp;
		private System.Windows.Forms.Label lblInfoUnicamp;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label lblCursosUnesp;
		private System.Windows.Forms.Label lblInfoUnesp;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label lblCursosUSP;
		private System.Windows.Forms.Label lblInfoUSP;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label lblMaterias;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Label lblHome;
		private System.Windows.Forms.Label lblPontuacao;
		private System.Windows.Forms.Label lblAssinaturas;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button btnA;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Panel panel9;
		private System.Windows.Forms.Button btnD;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button btnC;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.Button btnB;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Panel panel3;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Pergunta2MTForm));
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label7 = new System.Windows.Forms.Label();
			this.lblVestibulares = new System.Windows.Forms.Label();
			this.lblCursosFatec = new System.Windows.Forms.Label();
			this.lblInfoFatec = new System.Windows.Forms.Label();
			this.lblFatec = new System.Windows.Forms.Label();
			this.lblCursosUnicamp = new System.Windows.Forms.Label();
			this.lblInfoUnicamp = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.lblCursosUnesp = new System.Windows.Forms.Label();
			this.lblInfoUnesp = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.lblCursosUSP = new System.Windows.Forms.Label();
			this.lblInfoUSP = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.lblMaterias = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.lblHome = new System.Windows.Forms.Label();
			this.lblPontuacao = new System.Windows.Forms.Label();
			this.lblAssinaturas = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.btnA = new System.Windows.Forms.Button();
			this.label13 = new System.Windows.Forms.Label();
			this.panel9 = new System.Windows.Forms.Panel();
			this.btnD = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.btnC = new System.Windows.Forms.Button();
			this.label12 = new System.Windows.Forms.Label();
			this.panel8 = new System.Windows.Forms.Panel();
			this.btnB = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.panel3 = new System.Windows.Forms.Panel();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.panel1.SuspendLayout();
			this.panel9.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel8.SuspendLayout();
			this.panel3.SuspendLayout();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(19, 3);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(101, 64);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 1;
			this.pictureBox1.TabStop = false;
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.Location = new System.Drawing.Point(3, 139);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(29, 23);
			this.label7.TabIndex = 6;
			this.label7.Text = "➔ ";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblVestibulares
			// 
			this.lblVestibulares.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblVestibulares.Location = new System.Drawing.Point(25, 140);
			this.lblVestibulares.Name = "lblVestibulares";
			this.lblVestibulares.Size = new System.Drawing.Size(119, 23);
			this.lblVestibulares.TabIndex = 7;
			this.lblVestibulares.Text = "Vestibulares";
			this.lblVestibulares.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblCursosFatec
			// 
			this.lblCursosFatec.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosFatec.Location = new System.Drawing.Point(13, 463);
			this.lblCursosFatec.Name = "lblCursosFatec";
			this.lblCursosFatec.Size = new System.Drawing.Size(107, 24);
			this.lblCursosFatec.TabIndex = 19;
			this.lblCursosFatec.Text = "• Cursos";
			this.lblCursosFatec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosFatec.Click += new System.EventHandler(this.LblCursosFatecClick);
			// 
			// lblInfoFatec
			// 
			this.lblInfoFatec.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoFatec.Location = new System.Drawing.Point(13, 447);
			this.lblInfoFatec.Name = "lblInfoFatec";
			this.lblInfoFatec.Size = new System.Drawing.Size(107, 23);
			this.lblInfoFatec.TabIndex = 18;
			this.lblInfoFatec.Text = "• Informações";
			this.lblInfoFatec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoFatec.Click += new System.EventHandler(this.LblInfoFatecClick);
			// 
			// lblFatec
			// 
			this.lblFatec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFatec.Location = new System.Drawing.Point(13, 427);
			this.lblFatec.Name = "lblFatec";
			this.lblFatec.Size = new System.Drawing.Size(107, 23);
			this.lblFatec.TabIndex = 17;
			this.lblFatec.Text = "Fatec";
			this.lblFatec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblCursosUnicamp
			// 
			this.lblCursosUnicamp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosUnicamp.Location = new System.Drawing.Point(13, 394);
			this.lblCursosUnicamp.Name = "lblCursosUnicamp";
			this.lblCursosUnicamp.Size = new System.Drawing.Size(107, 24);
			this.lblCursosUnicamp.TabIndex = 22;
			this.lblCursosUnicamp.Text = "• Cursos";
			this.lblCursosUnicamp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosUnicamp.Click += new System.EventHandler(this.LblCursosUnicampClick);
			// 
			// lblInfoUnicamp
			// 
			this.lblInfoUnicamp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoUnicamp.Location = new System.Drawing.Point(13, 378);
			this.lblInfoUnicamp.Name = "lblInfoUnicamp";
			this.lblInfoUnicamp.Size = new System.Drawing.Size(107, 23);
			this.lblInfoUnicamp.TabIndex = 21;
			this.lblInfoUnicamp.Text = "• Informações";
			this.lblInfoUnicamp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoUnicamp.Click += new System.EventHandler(this.LblInfoUnicampClick);
			// 
			// label11
			// 
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.Location = new System.Drawing.Point(13, 358);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(107, 23);
			this.label11.TabIndex = 20;
			this.label11.Text = "Unicamp";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblCursosUnesp
			// 
			this.lblCursosUnesp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosUnesp.Location = new System.Drawing.Point(13, 323);
			this.lblCursosUnesp.Name = "lblCursosUnesp";
			this.lblCursosUnesp.Size = new System.Drawing.Size(107, 24);
			this.lblCursosUnesp.TabIndex = 25;
			this.lblCursosUnesp.Text = "• Cursos";
			this.lblCursosUnesp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosUnesp.Click += new System.EventHandler(this.LblCursosUnespClick);
			// 
			// lblInfoUnesp
			// 
			this.lblInfoUnesp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoUnesp.Location = new System.Drawing.Point(13, 307);
			this.lblInfoUnesp.Name = "lblInfoUnesp";
			this.lblInfoUnesp.Size = new System.Drawing.Size(107, 23);
			this.lblInfoUnesp.TabIndex = 24;
			this.lblInfoUnesp.Text = "• Informações";
			this.lblInfoUnesp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoUnesp.Click += new System.EventHandler(this.LblInfoUnespClick);
			// 
			// label14
			// 
			this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.Location = new System.Drawing.Point(13, 286);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(107, 23);
			this.label14.TabIndex = 23;
			this.label14.Text = "Unesp";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblCursosUSP
			// 
			this.lblCursosUSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosUSP.Location = new System.Drawing.Point(13, 254);
			this.lblCursosUSP.Name = "lblCursosUSP";
			this.lblCursosUSP.Size = new System.Drawing.Size(107, 24);
			this.lblCursosUSP.TabIndex = 28;
			this.lblCursosUSP.Text = "• Cursos";
			this.lblCursosUSP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosUSP.Click += new System.EventHandler(this.LblCursosUSPClick);
			// 
			// lblInfoUSP
			// 
			this.lblInfoUSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoUSP.Location = new System.Drawing.Point(13, 238);
			this.lblInfoUSP.Name = "lblInfoUSP";
			this.lblInfoUSP.Size = new System.Drawing.Size(145, 23);
			this.lblInfoUSP.TabIndex = 27;
			this.lblInfoUSP.Text = "• Informações";
			this.lblInfoUSP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoUSP.Click += new System.EventHandler(this.LblInfoUSPClick);
			// 
			// label17
			// 
			this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label17.Location = new System.Drawing.Point(13, 215);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(107, 23);
			this.label17.TabIndex = 26;
			this.label17.Text = "USP";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblMaterias
			// 
			this.lblMaterias.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblMaterias.Location = new System.Drawing.Point(13, 184);
			this.lblMaterias.Name = "lblMaterias";
			this.lblMaterias.Size = new System.Drawing.Size(107, 23);
			this.lblMaterias.TabIndex = 30;
			this.lblMaterias.Text = "• Matérias";
			this.lblMaterias.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblMaterias.Click += new System.EventHandler(this.LblMateriasClick);
			// 
			// label20
			// 
			this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label20.Location = new System.Drawing.Point(13, 164);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(131, 23);
			this.label20.TabIndex = 29;
			this.label20.Text = "Provão Paulista";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label24
			// 
			this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label24.Location = new System.Drawing.Point(3, 63);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(29, 23);
			this.label24.TabIndex = 23;
			this.label24.Text = "➔ ";
			this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblHome
			// 
			this.lblHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblHome.Location = new System.Drawing.Point(25, 64);
			this.lblHome.Name = "lblHome";
			this.lblHome.Size = new System.Drawing.Size(119, 23);
			this.lblHome.TabIndex = 24;
			this.lblHome.Text = "Tela Inicial";
			this.lblHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblHome.Click += new System.EventHandler(this.LblHomeClick);
			// 
			// lblPontuacao
			// 
			this.lblPontuacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPontuacao.Location = new System.Drawing.Point(13, 87);
			this.lblPontuacao.Name = "lblPontuacao";
			this.lblPontuacao.Size = new System.Drawing.Size(131, 23);
			this.lblPontuacao.TabIndex = 31;
			this.lblPontuacao.Text = "Pontuação";
			this.lblPontuacao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblPontuacao.Click += new System.EventHandler(this.LblPontuacaoClick);
			// 
			// lblAssinaturas
			// 
			this.lblAssinaturas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAssinaturas.Location = new System.Drawing.Point(13, 110);
			this.lblAssinaturas.Name = "lblAssinaturas";
			this.lblAssinaturas.Size = new System.Drawing.Size(131, 23);
			this.lblAssinaturas.TabIndex = 32;
			this.lblAssinaturas.Text = "Assinaturas";
			this.lblAssinaturas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblAssinaturas.Click += new System.EventHandler(this.LblAssinaturasClick);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.DarkRed;
			this.panel1.Controls.Add(this.lblAssinaturas);
			this.panel1.Controls.Add(this.lblPontuacao);
			this.panel1.Controls.Add(this.lblHome);
			this.panel1.Controls.Add(this.label24);
			this.panel1.Controls.Add(this.label20);
			this.panel1.Controls.Add(this.lblMaterias);
			this.panel1.Controls.Add(this.label17);
			this.panel1.Controls.Add(this.lblInfoUSP);
			this.panel1.Controls.Add(this.lblCursosUSP);
			this.panel1.Controls.Add(this.label14);
			this.panel1.Controls.Add(this.lblInfoUnesp);
			this.panel1.Controls.Add(this.lblCursosUnesp);
			this.panel1.Controls.Add(this.label11);
			this.panel1.Controls.Add(this.lblInfoUnicamp);
			this.panel1.Controls.Add(this.lblCursosUnicamp);
			this.panel1.Controls.Add(this.lblFatec);
			this.panel1.Controls.Add(this.lblInfoFatec);
			this.panel1.Controls.Add(this.lblCursosFatec);
			this.panel1.Controls.Add(this.lblVestibulares);
			this.panel1.Controls.Add(this.label7);
			this.panel1.Controls.Add(this.pictureBox1);
			this.panel1.ForeColor = System.Drawing.Color.Transparent;
			this.panel1.Location = new System.Drawing.Point(1, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(169, 512);
			this.panel1.TabIndex = 148;
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(176, 3);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(699, 48);
			this.label2.TabIndex = 149;
			this.label2.Text = "PERGUNTA 2";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(176, 38);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(699, 29);
			this.label4.TabIndex = 150;
			this.label4.Text = "QUIZ 1";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.Location = new System.Drawing.Point(176, 64);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(699, 171);
			this.label5.TabIndex = 151;
			this.label5.Text = resources.GetString("label5.Text");
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// btnA
			// 
			this.btnA.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.btnA.Font = new System.Drawing.Font("Microsoft YaHei UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnA.ForeColor = System.Drawing.Color.DarkRed;
			this.btnA.Location = new System.Drawing.Point(3, 3);
			this.btnA.Name = "btnA";
			this.btnA.Size = new System.Drawing.Size(61, 83);
			this.btnA.TabIndex = 0;
			this.btnA.Text = "A)";
			this.btnA.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnA.UseVisualStyleBackColor = false;
			this.btnA.Click += new System.EventHandler(this.BtnAClick);
			// 
			// label13
			// 
			this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label13.Location = new System.Drawing.Point(70, 3);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(236, 83);
			this.label13.TabIndex = 51;
			this.label13.Text = "A) 400 unidades";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel9
			// 
			this.panel9.Controls.Add(this.label13);
			this.panel9.Controls.Add(this.btnA);
			this.panel9.Location = new System.Drawing.Point(190, 200);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(323, 89);
			this.panel9.TabIndex = 153;
			// 
			// btnD
			// 
			this.btnD.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.btnD.Font = new System.Drawing.Font("Microsoft YaHei UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnD.ForeColor = System.Drawing.Color.DarkRed;
			this.btnD.Location = new System.Drawing.Point(3, 3);
			this.btnD.Name = "btnD";
			this.btnD.Size = new System.Drawing.Size(61, 83);
			this.btnD.TabIndex = 0;
			this.btnD.Text = "D)";
			this.btnD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnD.UseVisualStyleBackColor = false;
			this.btnD.Click += new System.EventHandler(this.BtnDClick);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(70, 3);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(236, 83);
			this.label1.TabIndex = 51;
			this.label1.Text = "D) 800 unidades";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.label1);
			this.panel2.Controls.Add(this.btnD);
			this.panel2.Location = new System.Drawing.Point(532, 300);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(323, 89);
			this.panel2.TabIndex = 157;
			// 
			// btnC
			// 
			this.btnC.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.btnC.Font = new System.Drawing.Font("Microsoft YaHei UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnC.ForeColor = System.Drawing.Color.DarkRed;
			this.btnC.Location = new System.Drawing.Point(3, 3);
			this.btnC.Name = "btnC";
			this.btnC.Size = new System.Drawing.Size(61, 83);
			this.btnC.TabIndex = 0;
			this.btnC.Text = "C)";
			this.btnC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnC.UseVisualStyleBackColor = false;
			this.btnC.Click += new System.EventHandler(this.BtnCClick);
			// 
			// label12
			// 
			this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.Location = new System.Drawing.Point(70, 3);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(236, 83);
			this.label12.TabIndex = 51;
			this.label12.Text = "C) 700 unidades";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel8
			// 
			this.panel8.Controls.Add(this.label12);
			this.panel8.Controls.Add(this.btnC);
			this.panel8.Location = new System.Drawing.Point(532, 200);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(323, 89);
			this.panel8.TabIndex = 156;
			// 
			// btnB
			// 
			this.btnB.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.btnB.Font = new System.Drawing.Font("Microsoft YaHei UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnB.ForeColor = System.Drawing.Color.DarkRed;
			this.btnB.Location = new System.Drawing.Point(3, 3);
			this.btnB.Name = "btnB";
			this.btnB.Size = new System.Drawing.Size(61, 83);
			this.btnB.TabIndex = 0;
			this.btnB.Text = "B)";
			this.btnB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnB.UseVisualStyleBackColor = false;
			this.btnB.Click += new System.EventHandler(this.BtnBClick);
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(70, 3);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(236, 83);
			this.label3.TabIndex = 51;
			this.label3.Text = "B) 600 unidades";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.label3);
			this.panel3.Controls.Add(this.btnB);
			this.panel3.Location = new System.Drawing.Point(190, 300);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(323, 89);
			this.panel3.TabIndex = 155;
			// 
			// Pergunta2MTForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(877, 512);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel8);
			this.Controls.Add(this.panel9);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.panel1);
			this.Name = "Pergunta2MTForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Pergunta2MTForm";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.panel1.ResumeLayout(false);
			this.panel9.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panel8.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.ResumeLayout(false);

		}
	}
}
