﻿/*
 * Created by SharpDevelop.
 * User: jenni
 * Date: 12/10/2025
 * Time: 20:26
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace SistemaQuiz
{
	partial class MateriasPVForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label lblAssinaturas;
		private System.Windows.Forms.Label lblPontuacao;
		private System.Windows.Forms.Label lblHome;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label lblMaterias;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label lblInfoUSP;
		private System.Windows.Forms.Label lblCursosUSP;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label lblInfoUnesp;
		private System.Windows.Forms.Label lblCursosUnesp;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label lblInfoUnicamp;
		private System.Windows.Forms.Label lblCursosUnicamp;
		private System.Windows.Forms.Label lblFatec;
		private System.Windows.Forms.Label lblInfoFatec;
		private System.Windows.Forms.Label lblCursosFatec;
		private System.Windows.Forms.Label lblVestibulares;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel10;
		private System.Windows.Forms.Button btnQuizIng;
		private System.Windows.Forms.Button btnResumoIng;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.Label label31;
		private System.Windows.Forms.Label label32;
		private System.Windows.Forms.Panel panel9;
		private System.Windows.Forms.Button btnQuizFi;
		private System.Windows.Forms.Button btnResumoFi;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.Button btnQuizQui;
		private System.Windows.Forms.Button btnResumoQui;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Button btnQuizBio;
		private System.Windows.Forms.Button btnResumoBio;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Button btnQuizGeo;
		private System.Windows.Forms.Button btnResumoGeo;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Button btnQuizHist;
		private System.Windows.Forms.Button btnResumoHist;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.Button btnQuizMat;
		private System.Windows.Forms.Button btnResumoMat;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Button btnQuizPort;
		private System.Windows.Forms.Button btnResumoPort;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MateriasPVForm));
			this.panel1 = new System.Windows.Forms.Panel();
			this.lblAssinaturas = new System.Windows.Forms.Label();
			this.lblPontuacao = new System.Windows.Forms.Label();
			this.lblHome = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.lblMaterias = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.lblInfoUSP = new System.Windows.Forms.Label();
			this.lblCursosUSP = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.lblInfoUnesp = new System.Windows.Forms.Label();
			this.lblCursosUnesp = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.lblInfoUnicamp = new System.Windows.Forms.Label();
			this.lblCursosUnicamp = new System.Windows.Forms.Label();
			this.lblFatec = new System.Windows.Forms.Label();
			this.lblInfoFatec = new System.Windows.Forms.Label();
			this.lblCursosFatec = new System.Windows.Forms.Label();
			this.lblVestibulares = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.btnQuizIng = new System.Windows.Forms.Button();
			this.btnResumoIng = new System.Windows.Forms.Button();
			this.label30 = new System.Windows.Forms.Label();
			this.label31 = new System.Windows.Forms.Label();
			this.label32 = new System.Windows.Forms.Label();
			this.panel9 = new System.Windows.Forms.Panel();
			this.btnQuizFi = new System.Windows.Forms.Button();
			this.btnResumoFi = new System.Windows.Forms.Button();
			this.label27 = new System.Windows.Forms.Label();
			this.label28 = new System.Windows.Forms.Label();
			this.label29 = new System.Windows.Forms.Label();
			this.panel7 = new System.Windows.Forms.Panel();
			this.btnQuizQui = new System.Windows.Forms.Button();
			this.btnResumoQui = new System.Windows.Forms.Button();
			this.label19 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.panel6 = new System.Windows.Forms.Panel();
			this.btnQuizBio = new System.Windows.Forms.Button();
			this.btnResumoBio = new System.Windows.Forms.Button();
			this.label15 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label18 = new System.Windows.Forms.Label();
			this.panel5 = new System.Windows.Forms.Panel();
			this.btnQuizGeo = new System.Windows.Forms.Button();
			this.btnResumoGeo = new System.Windows.Forms.Button();
			this.label10 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.panel4 = new System.Windows.Forms.Panel();
			this.btnQuizHist = new System.Windows.Forms.Button();
			this.btnResumoHist = new System.Windows.Forms.Button();
			this.label6 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.panel8 = new System.Windows.Forms.Panel();
			this.btnQuizMat = new System.Windows.Forms.Button();
			this.btnResumoMat = new System.Windows.Forms.Button();
			this.label23 = new System.Windows.Forms.Label();
			this.label25 = new System.Windows.Forms.Label();
			this.label26 = new System.Windows.Forms.Label();
			this.panel3 = new System.Windows.Forms.Panel();
			this.btnQuizPort = new System.Windows.Forms.Button();
			this.btnResumoPort = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.panel2.SuspendLayout();
			this.panel10.SuspendLayout();
			this.panel9.SuspendLayout();
			this.panel7.SuspendLayout();
			this.panel6.SuspendLayout();
			this.panel5.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel8.SuspendLayout();
			this.panel3.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.DarkRed;
			this.panel1.Controls.Add(this.lblAssinaturas);
			this.panel1.Controls.Add(this.lblPontuacao);
			this.panel1.Controls.Add(this.lblHome);
			this.panel1.Controls.Add(this.label24);
			this.panel1.Controls.Add(this.label20);
			this.panel1.Controls.Add(this.lblMaterias);
			this.panel1.Controls.Add(this.label17);
			this.panel1.Controls.Add(this.lblInfoUSP);
			this.panel1.Controls.Add(this.lblCursosUSP);
			this.panel1.Controls.Add(this.label14);
			this.panel1.Controls.Add(this.lblInfoUnesp);
			this.panel1.Controls.Add(this.lblCursosUnesp);
			this.panel1.Controls.Add(this.label11);
			this.panel1.Controls.Add(this.lblInfoUnicamp);
			this.panel1.Controls.Add(this.lblCursosUnicamp);
			this.panel1.Controls.Add(this.lblFatec);
			this.panel1.Controls.Add(this.lblInfoFatec);
			this.panel1.Controls.Add(this.lblCursosFatec);
			this.panel1.Controls.Add(this.lblVestibulares);
			this.panel1.Controls.Add(this.label7);
			this.panel1.Controls.Add(this.pictureBox1);
			this.panel1.ForeColor = System.Drawing.Color.Transparent;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(169, 512);
			this.panel1.TabIndex = 136;
			// 
			// lblAssinaturas
			// 
			this.lblAssinaturas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAssinaturas.Location = new System.Drawing.Point(13, 110);
			this.lblAssinaturas.Name = "lblAssinaturas";
			this.lblAssinaturas.Size = new System.Drawing.Size(131, 23);
			this.lblAssinaturas.TabIndex = 32;
			this.lblAssinaturas.Text = "Assinaturas";
			this.lblAssinaturas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblAssinaturas.Click += new System.EventHandler(this.LblAssinaturasClick);
			// 
			// lblPontuacao
			// 
			this.lblPontuacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPontuacao.Location = new System.Drawing.Point(13, 87);
			this.lblPontuacao.Name = "lblPontuacao";
			this.lblPontuacao.Size = new System.Drawing.Size(131, 23);
			this.lblPontuacao.TabIndex = 31;
			this.lblPontuacao.Text = "Pontuação";
			this.lblPontuacao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblPontuacao.Click += new System.EventHandler(this.LblPontuacaoClick);
			// 
			// lblHome
			// 
			this.lblHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblHome.Location = new System.Drawing.Point(25, 64);
			this.lblHome.Name = "lblHome";
			this.lblHome.Size = new System.Drawing.Size(119, 23);
			this.lblHome.TabIndex = 24;
			this.lblHome.Text = "Tela Inicial";
			this.lblHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblHome.Click += new System.EventHandler(this.LblHomeClick);
			// 
			// label24
			// 
			this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label24.Location = new System.Drawing.Point(3, 63);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(29, 23);
			this.label24.TabIndex = 23;
			this.label24.Text = "➔ ";
			this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label20
			// 
			this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label20.Location = new System.Drawing.Point(13, 164);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(131, 23);
			this.label20.TabIndex = 29;
			this.label20.Text = "Provão Paulista";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblMaterias
			// 
			this.lblMaterias.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblMaterias.Location = new System.Drawing.Point(13, 184);
			this.lblMaterias.Name = "lblMaterias";
			this.lblMaterias.Size = new System.Drawing.Size(107, 23);
			this.lblMaterias.TabIndex = 30;
			this.lblMaterias.Text = "• Matérias";
			this.lblMaterias.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblMaterias.Click += new System.EventHandler(this.LblMateriasClick);
			// 
			// label17
			// 
			this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label17.Location = new System.Drawing.Point(13, 215);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(107, 23);
			this.label17.TabIndex = 26;
			this.label17.Text = "USP";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblInfoUSP
			// 
			this.lblInfoUSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoUSP.Location = new System.Drawing.Point(13, 238);
			this.lblInfoUSP.Name = "lblInfoUSP";
			this.lblInfoUSP.Size = new System.Drawing.Size(145, 23);
			this.lblInfoUSP.TabIndex = 27;
			this.lblInfoUSP.Text = "• Informações";
			this.lblInfoUSP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoUSP.Click += new System.EventHandler(this.LblInfoUSPClick);
			// 
			// lblCursosUSP
			// 
			this.lblCursosUSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosUSP.Location = new System.Drawing.Point(13, 254);
			this.lblCursosUSP.Name = "lblCursosUSP";
			this.lblCursosUSP.Size = new System.Drawing.Size(107, 24);
			this.lblCursosUSP.TabIndex = 28;
			this.lblCursosUSP.Text = "• Cursos";
			this.lblCursosUSP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosUSP.Click += new System.EventHandler(this.LblCursosUSPClick);
			// 
			// label14
			// 
			this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.Location = new System.Drawing.Point(13, 286);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(107, 23);
			this.label14.TabIndex = 23;
			this.label14.Text = "Unesp";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblInfoUnesp
			// 
			this.lblInfoUnesp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoUnesp.Location = new System.Drawing.Point(13, 307);
			this.lblInfoUnesp.Name = "lblInfoUnesp";
			this.lblInfoUnesp.Size = new System.Drawing.Size(107, 23);
			this.lblInfoUnesp.TabIndex = 24;
			this.lblInfoUnesp.Text = "• Informações";
			this.lblInfoUnesp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoUnesp.Click += new System.EventHandler(this.LblInfoUnespClick);
			// 
			// lblCursosUnesp
			// 
			this.lblCursosUnesp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosUnesp.Location = new System.Drawing.Point(13, 323);
			this.lblCursosUnesp.Name = "lblCursosUnesp";
			this.lblCursosUnesp.Size = new System.Drawing.Size(107, 24);
			this.lblCursosUnesp.TabIndex = 25;
			this.lblCursosUnesp.Text = "• Cursos";
			this.lblCursosUnesp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosUnesp.Click += new System.EventHandler(this.LblCursosUnespClick);
			// 
			// label11
			// 
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.Location = new System.Drawing.Point(13, 358);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(107, 23);
			this.label11.TabIndex = 20;
			this.label11.Text = "Unicamp";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblInfoUnicamp
			// 
			this.lblInfoUnicamp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoUnicamp.Location = new System.Drawing.Point(13, 378);
			this.lblInfoUnicamp.Name = "lblInfoUnicamp";
			this.lblInfoUnicamp.Size = new System.Drawing.Size(107, 23);
			this.lblInfoUnicamp.TabIndex = 21;
			this.lblInfoUnicamp.Text = "• Informações";
			this.lblInfoUnicamp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoUnicamp.Click += new System.EventHandler(this.LblInfoUnicampClick);
			// 
			// lblCursosUnicamp
			// 
			this.lblCursosUnicamp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosUnicamp.Location = new System.Drawing.Point(13, 394);
			this.lblCursosUnicamp.Name = "lblCursosUnicamp";
			this.lblCursosUnicamp.Size = new System.Drawing.Size(107, 24);
			this.lblCursosUnicamp.TabIndex = 22;
			this.lblCursosUnicamp.Text = "• Cursos";
			this.lblCursosUnicamp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosUnicamp.Click += new System.EventHandler(this.LblCursosUnicampClick);
			// 
			// lblFatec
			// 
			this.lblFatec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFatec.Location = new System.Drawing.Point(13, 427);
			this.lblFatec.Name = "lblFatec";
			this.lblFatec.Size = new System.Drawing.Size(107, 23);
			this.lblFatec.TabIndex = 17;
			this.lblFatec.Text = "Fatec";
			this.lblFatec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblInfoFatec
			// 
			this.lblInfoFatec.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoFatec.Location = new System.Drawing.Point(13, 447);
			this.lblInfoFatec.Name = "lblInfoFatec";
			this.lblInfoFatec.Size = new System.Drawing.Size(107, 23);
			this.lblInfoFatec.TabIndex = 18;
			this.lblInfoFatec.Text = "• Informações";
			this.lblInfoFatec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoFatec.Click += new System.EventHandler(this.LblInfoFatecClick);
			// 
			// lblCursosFatec
			// 
			this.lblCursosFatec.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosFatec.Location = new System.Drawing.Point(13, 463);
			this.lblCursosFatec.Name = "lblCursosFatec";
			this.lblCursosFatec.Size = new System.Drawing.Size(107, 24);
			this.lblCursosFatec.TabIndex = 19;
			this.lblCursosFatec.Text = "• Cursos";
			this.lblCursosFatec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosFatec.Click += new System.EventHandler(this.LblCursosFatecClick);
			// 
			// lblVestibulares
			// 
			this.lblVestibulares.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblVestibulares.Location = new System.Drawing.Point(25, 140);
			this.lblVestibulares.Name = "lblVestibulares";
			this.lblVestibulares.Size = new System.Drawing.Size(119, 23);
			this.lblVestibulares.TabIndex = 7;
			this.lblVestibulares.Text = "Vestibulares";
			this.lblVestibulares.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.Location = new System.Drawing.Point(3, 139);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(29, 23);
			this.label7.TabIndex = 6;
			this.label7.Text = "➔ ";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(19, 3);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(101, 64);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 1;
			this.pictureBox1.TabStop = false;
			// 
			// panel2
			// 
			this.panel2.AutoScroll = true;
			this.panel2.AutoScrollMinSize = new System.Drawing.Size(0, 800);
			this.panel2.Controls.Add(this.panel10);
			this.panel2.Controls.Add(this.panel9);
			this.panel2.Controls.Add(this.panel7);
			this.panel2.Controls.Add(this.panel6);
			this.panel2.Controls.Add(this.panel5);
			this.panel2.Controls.Add(this.panel4);
			this.panel2.Controls.Add(this.panel8);
			this.panel2.Controls.Add(this.panel3);
			this.panel2.Controls.Add(this.label2);
			this.panel2.Controls.Add(this.label1);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel2.Location = new System.Drawing.Point(175, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(702, 505);
			this.panel2.TabIndex = 137;
			// 
			// panel10
			// 
			this.panel10.BackColor = System.Drawing.Color.MistyRose;
			this.panel10.Controls.Add(this.btnQuizIng);
			this.panel10.Controls.Add(this.btnResumoIng);
			this.panel10.Controls.Add(this.label30);
			this.panel10.Controls.Add(this.label31);
			this.panel10.Controls.Add(this.label32);
			this.panel10.Location = new System.Drawing.Point(12, 682);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(662, 76);
			this.panel10.TabIndex = 150;
			// 
			// btnQuizIng
			// 
			this.btnQuizIng.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnQuizIng.ForeColor = System.Drawing.Color.LightCoral;
			this.btnQuizIng.Location = new System.Drawing.Point(558, 41);
			this.btnQuizIng.Name = "btnQuizIng";
			this.btnQuizIng.Size = new System.Drawing.Size(98, 23);
			this.btnQuizIng.TabIndex = 140;
			this.btnQuizIng.Text = "QUIZZES";
			this.btnQuizIng.UseVisualStyleBackColor = true;
			this.btnQuizIng.Click += new System.EventHandler(this.BtnQuizIngClick);
			// 
			// btnResumoIng
			// 
			this.btnResumoIng.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnResumoIng.ForeColor = System.Drawing.Color.LightCoral;
			this.btnResumoIng.Location = new System.Drawing.Point(558, 12);
			this.btnResumoIng.Name = "btnResumoIng";
			this.btnResumoIng.Size = new System.Drawing.Size(98, 23);
			this.btnResumoIng.TabIndex = 139;
			this.btnResumoIng.Text = "RESUMOS";
			this.btnResumoIng.UseVisualStyleBackColor = true;
			this.btnResumoIng.Click += new System.EventHandler(this.BtnResumoIngClick);
			// 
			// label30
			// 
			this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label30.ForeColor = System.Drawing.Color.Black;
			this.label30.Location = new System.Drawing.Point(13, 33);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(539, 40);
			this.label30.TabIndex = 138;
			this.label30.Text = "Na prova de História, são cobrados fatos importantes do Brasil e do mundo, analis" +
	"ando contextos, causas e consequências, reflexão sobre o passado e o presente.";
			// 
			// label31
			// 
			this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label31.ForeColor = System.Drawing.Color.Black;
			this.label31.Location = new System.Drawing.Point(96, 3);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(579, 39);
			this.label31.TabIndex = 137;
			this.label31.Text = "→ 1 resumo, 1 quiz";
			this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label32
			// 
			this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label32.ForeColor = System.Drawing.Color.Black;
			this.label32.Location = new System.Drawing.Point(13, 2);
			this.label32.Name = "label32";
			this.label32.Size = new System.Drawing.Size(662, 39);
			this.label32.TabIndex = 136;
			this.label32.Text = "INGLÊS";
			this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel9
			// 
			this.panel9.BackColor = System.Drawing.Color.Salmon;
			this.panel9.Controls.Add(this.btnQuizFi);
			this.panel9.Controls.Add(this.btnResumoFi);
			this.panel9.Controls.Add(this.label27);
			this.panel9.Controls.Add(this.label28);
			this.panel9.Controls.Add(this.label29);
			this.panel9.Location = new System.Drawing.Point(12, 595);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(662, 76);
			this.panel9.TabIndex = 151;
			// 
			// btnQuizFi
			// 
			this.btnQuizFi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnQuizFi.ForeColor = System.Drawing.Color.Salmon;
			this.btnQuizFi.Location = new System.Drawing.Point(558, 41);
			this.btnQuizFi.Name = "btnQuizFi";
			this.btnQuizFi.Size = new System.Drawing.Size(98, 23);
			this.btnQuizFi.TabIndex = 140;
			this.btnQuizFi.Text = "QUIZZES";
			this.btnQuizFi.UseVisualStyleBackColor = true;
			this.btnQuizFi.Click += new System.EventHandler(this.BtnQuizFiClick);
			// 
			// btnResumoFi
			// 
			this.btnResumoFi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnResumoFi.ForeColor = System.Drawing.Color.Salmon;
			this.btnResumoFi.Location = new System.Drawing.Point(558, 12);
			this.btnResumoFi.Name = "btnResumoFi";
			this.btnResumoFi.Size = new System.Drawing.Size(98, 23);
			this.btnResumoFi.TabIndex = 139;
			this.btnResumoFi.Text = "RESUMOS";
			this.btnResumoFi.UseVisualStyleBackColor = true;
			this.btnResumoFi.Click += new System.EventHandler(this.BtnResumoFiClick);
			// 
			// label27
			// 
			this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label27.ForeColor = System.Drawing.Color.Black;
			this.label27.Location = new System.Drawing.Point(13, 33);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(539, 40);
			this.label27.TabIndex = 138;
			this.label27.Text = "Na prova de História, são cobrados fatos importantes do Brasil e do mundo, analis" +
	"ando contextos, causas e consequências, reflexão sobre o passado e o presente.";
			// 
			// label28
			// 
			this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label28.ForeColor = System.Drawing.Color.Black;
			this.label28.Location = new System.Drawing.Point(84, 3);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(591, 39);
			this.label28.TabIndex = 137;
			this.label28.Text = "→ 1 resumo, 1 quiz";
			this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label29
			// 
			this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label29.ForeColor = System.Drawing.Color.Black;
			this.label29.Location = new System.Drawing.Point(13, 2);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(662, 39);
			this.label29.TabIndex = 136;
			this.label29.Text = "FÍSICA";
			this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel7
			// 
			this.panel7.BackColor = System.Drawing.Color.LightCoral;
			this.panel7.Controls.Add(this.btnQuizQui);
			this.panel7.Controls.Add(this.btnResumoQui);
			this.panel7.Controls.Add(this.label19);
			this.panel7.Controls.Add(this.label21);
			this.panel7.Controls.Add(this.label22);
			this.panel7.Location = new System.Drawing.Point(12, 509);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(662, 76);
			this.panel7.TabIndex = 150;
			// 
			// btnQuizQui
			// 
			this.btnQuizQui.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnQuizQui.ForeColor = System.Drawing.Color.LightCoral;
			this.btnQuizQui.Location = new System.Drawing.Point(558, 40);
			this.btnQuizQui.Name = "btnQuizQui";
			this.btnQuizQui.Size = new System.Drawing.Size(98, 23);
			this.btnQuizQui.TabIndex = 140;
			this.btnQuizQui.Text = "QUIZZES";
			this.btnQuizQui.UseVisualStyleBackColor = true;
			this.btnQuizQui.Click += new System.EventHandler(this.BtnQuizQuiClick);
			// 
			// btnResumoQui
			// 
			this.btnResumoQui.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnResumoQui.ForeColor = System.Drawing.Color.LightCoral;
			this.btnResumoQui.Location = new System.Drawing.Point(558, 11);
			this.btnResumoQui.Name = "btnResumoQui";
			this.btnResumoQui.Size = new System.Drawing.Size(98, 23);
			this.btnResumoQui.TabIndex = 139;
			this.btnResumoQui.Text = "RESUMOS";
			this.btnResumoQui.UseVisualStyleBackColor = true;
			this.btnResumoQui.Click += new System.EventHandler(this.BtnResumoQuiClick);
			// 
			// label19
			// 
			this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label19.ForeColor = System.Drawing.Color.Black;
			this.label19.Location = new System.Drawing.Point(13, 33);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(539, 40);
			this.label19.TabIndex = 138;
			this.label19.Text = "Na prova de História, são cobrados fatos importantes do Brasil e do mundo, analis" +
	"ando contextos, causas e consequências, reflexão sobre o passado e o presente.";
			// 
			// label21
			// 
			this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label21.ForeColor = System.Drawing.Color.Black;
			this.label21.Location = new System.Drawing.Point(107, 3);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(568, 39);
			this.label21.TabIndex = 137;
			this.label21.Text = "→ 1 resumo, 1 quiz";
			this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label22
			// 
			this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label22.ForeColor = System.Drawing.Color.Black;
			this.label22.Location = new System.Drawing.Point(13, 2);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(662, 39);
			this.label22.TabIndex = 136;
			this.label22.Text = "QUÍMICA";
			this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel6
			// 
			this.panel6.BackColor = System.Drawing.Color.IndianRed;
			this.panel6.Controls.Add(this.btnQuizBio);
			this.panel6.Controls.Add(this.btnResumoBio);
			this.panel6.Controls.Add(this.label15);
			this.panel6.Controls.Add(this.label16);
			this.panel6.Controls.Add(this.label18);
			this.panel6.Location = new System.Drawing.Point(12, 423);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(662, 76);
			this.panel6.TabIndex = 149;
			// 
			// btnQuizBio
			// 
			this.btnQuizBio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnQuizBio.ForeColor = System.Drawing.Color.IndianRed;
			this.btnQuizBio.Location = new System.Drawing.Point(558, 41);
			this.btnQuizBio.Name = "btnQuizBio";
			this.btnQuizBio.Size = new System.Drawing.Size(98, 23);
			this.btnQuizBio.TabIndex = 140;
			this.btnQuizBio.Text = "QUIZZES";
			this.btnQuizBio.UseVisualStyleBackColor = true;
			this.btnQuizBio.Click += new System.EventHandler(this.BtnQuizBioClick);
			// 
			// btnResumoBio
			// 
			this.btnResumoBio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnResumoBio.ForeColor = System.Drawing.Color.IndianRed;
			this.btnResumoBio.Location = new System.Drawing.Point(558, 11);
			this.btnResumoBio.Name = "btnResumoBio";
			this.btnResumoBio.Size = new System.Drawing.Size(98, 23);
			this.btnResumoBio.TabIndex = 139;
			this.btnResumoBio.Text = "RESUMOS";
			this.btnResumoBio.UseVisualStyleBackColor = true;
			this.btnResumoBio.Click += new System.EventHandler(this.BtnResumoBioClick);
			// 
			// label15
			// 
			this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label15.ForeColor = System.Drawing.Color.White;
			this.label15.Location = new System.Drawing.Point(13, 33);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(539, 40);
			this.label15.TabIndex = 138;
			this.label15.Text = "Na prova de História, são cobrados fatos importantes do Brasil e do mundo, analis" +
	"ando contextos, causas e consequências, reflexão sobre o passado e o presente.";
			// 
			// label16
			// 
			this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label16.ForeColor = System.Drawing.Color.White;
			this.label16.Location = new System.Drawing.Point(150, 3);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(525, 39);
			this.label16.TabIndex = 137;
			this.label16.Text = "→ 1 resumo, 1 quiz";
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label18
			// 
			this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label18.ForeColor = System.Drawing.Color.White;
			this.label18.Location = new System.Drawing.Point(13, 2);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(662, 39);
			this.label18.TabIndex = 136;
			this.label18.Text = "BIOLOGIA";
			this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.Color.Brown;
			this.panel5.Controls.Add(this.btnQuizGeo);
			this.panel5.Controls.Add(this.btnResumoGeo);
			this.panel5.Controls.Add(this.label10);
			this.panel5.Controls.Add(this.label12);
			this.panel5.Controls.Add(this.label13);
			this.panel5.Location = new System.Drawing.Point(12, 336);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(662, 76);
			this.panel5.TabIndex = 148;
			// 
			// btnQuizGeo
			// 
			this.btnQuizGeo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnQuizGeo.ForeColor = System.Drawing.Color.Firebrick;
			this.btnQuizGeo.Location = new System.Drawing.Point(558, 41);
			this.btnQuizGeo.Name = "btnQuizGeo";
			this.btnQuizGeo.Size = new System.Drawing.Size(98, 23);
			this.btnQuizGeo.TabIndex = 140;
			this.btnQuizGeo.Text = "QUIZZES";
			this.btnQuizGeo.UseVisualStyleBackColor = true;
			this.btnQuizGeo.Click += new System.EventHandler(this.BtnQuizGeoClick);
			// 
			// btnResumoGeo
			// 
			this.btnResumoGeo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnResumoGeo.ForeColor = System.Drawing.Color.Firebrick;
			this.btnResumoGeo.Location = new System.Drawing.Point(558, 12);
			this.btnResumoGeo.Name = "btnResumoGeo";
			this.btnResumoGeo.Size = new System.Drawing.Size(98, 23);
			this.btnResumoGeo.TabIndex = 139;
			this.btnResumoGeo.Text = "RESUMOS";
			this.btnResumoGeo.UseVisualStyleBackColor = true;
			this.btnResumoGeo.Click += new System.EventHandler(this.BtnResumoGeoClick);
			// 
			// label10
			// 
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10.ForeColor = System.Drawing.Color.White;
			this.label10.Location = new System.Drawing.Point(13, 33);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(539, 40);
			this.label10.TabIndex = 138;
			this.label10.Text = "Na prova de História, são cobrados fatos importantes do Brasil e do mundo, analis" +
	"ando contextos, causas e consequências, reflexão sobre o passado e o presente.";
			// 
			// label12
			// 
			this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.ForeColor = System.Drawing.Color.White;
			this.label12.Location = new System.Drawing.Point(150, 3);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(525, 39);
			this.label12.TabIndex = 137;
			this.label12.Text = "→ 1 resumo, 1 quiz";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label13
			// 
			this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label13.ForeColor = System.Drawing.Color.White;
			this.label13.Location = new System.Drawing.Point(13, 2);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(662, 39);
			this.label13.TabIndex = 136;
			this.label13.Text = "GEOGRAFIA";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.Color.Firebrick;
			this.panel4.Controls.Add(this.btnQuizHist);
			this.panel4.Controls.Add(this.btnResumoHist);
			this.panel4.Controls.Add(this.label6);
			this.panel4.Controls.Add(this.label8);
			this.panel4.Controls.Add(this.label9);
			this.panel4.Location = new System.Drawing.Point(12, 250);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(662, 76);
			this.panel4.TabIndex = 147;
			// 
			// btnQuizHist
			// 
			this.btnQuizHist.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnQuizHist.ForeColor = System.Drawing.Color.Firebrick;
			this.btnQuizHist.Location = new System.Drawing.Point(558, 40);
			this.btnQuizHist.Name = "btnQuizHist";
			this.btnQuizHist.Size = new System.Drawing.Size(98, 23);
			this.btnQuizHist.TabIndex = 140;
			this.btnQuizHist.Text = "QUIZZES";
			this.btnQuizHist.UseVisualStyleBackColor = true;
			this.btnQuizHist.Click += new System.EventHandler(this.BtnQuizHistClick);
			// 
			// btnResumoHist
			// 
			this.btnResumoHist.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnResumoHist.ForeColor = System.Drawing.Color.Firebrick;
			this.btnResumoHist.Location = new System.Drawing.Point(558, 11);
			this.btnResumoHist.Name = "btnResumoHist";
			this.btnResumoHist.Size = new System.Drawing.Size(98, 23);
			this.btnResumoHist.TabIndex = 139;
			this.btnResumoHist.Text = "RESUMOS";
			this.btnResumoHist.UseVisualStyleBackColor = true;
			this.btnResumoHist.Click += new System.EventHandler(this.BtnResumoHistClick);
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.White;
			this.label6.Location = new System.Drawing.Point(13, 33);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(539, 40);
			this.label6.TabIndex = 138;
			this.label6.Text = "Na prova de História, são cobrados fatos importantes do Brasil e do mundo, analis" +
	"ando contextos, causas e consequências, reflexão sobre o passado e o presente.";
			// 
			// label8
			// 
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.ForeColor = System.Drawing.Color.White;
			this.label8.Location = new System.Drawing.Point(150, 3);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(525, 39);
			this.label8.TabIndex = 137;
			this.label8.Text = "→ 1 resumo, 1 quiz";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label9
			// 
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label9.ForeColor = System.Drawing.Color.White;
			this.label9.Location = new System.Drawing.Point(13, 2);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(662, 39);
			this.label9.TabIndex = 136;
			this.label9.Text = "HISTÓRIA";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel8
			// 
			this.panel8.BackColor = System.Drawing.Color.DarkRed;
			this.panel8.Controls.Add(this.btnQuizMat);
			this.panel8.Controls.Add(this.btnResumoMat);
			this.panel8.Controls.Add(this.label23);
			this.panel8.Controls.Add(this.label25);
			this.panel8.Controls.Add(this.label26);
			this.panel8.Location = new System.Drawing.Point(12, 164);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(662, 76);
			this.panel8.TabIndex = 146;
			// 
			// btnQuizMat
			// 
			this.btnQuizMat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnQuizMat.ForeColor = System.Drawing.Color.DarkRed;
			this.btnQuizMat.Location = new System.Drawing.Point(558, 41);
			this.btnQuizMat.Name = "btnQuizMat";
			this.btnQuizMat.Size = new System.Drawing.Size(98, 23);
			this.btnQuizMat.TabIndex = 140;
			this.btnQuizMat.Text = "QUIZZES";
			this.btnQuizMat.UseVisualStyleBackColor = true;
			this.btnQuizMat.Click += new System.EventHandler(this.BtnQuizMatClick);
			// 
			// btnResumoMat
			// 
			this.btnResumoMat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnResumoMat.ForeColor = System.Drawing.Color.DarkRed;
			this.btnResumoMat.Location = new System.Drawing.Point(558, 12);
			this.btnResumoMat.Name = "btnResumoMat";
			this.btnResumoMat.Size = new System.Drawing.Size(98, 23);
			this.btnResumoMat.TabIndex = 139;
			this.btnResumoMat.Text = "RESUMOS";
			this.btnResumoMat.UseVisualStyleBackColor = true;
			this.btnResumoMat.Click += new System.EventHandler(this.BtnResumoMatClick);
			// 
			// label23
			// 
			this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label23.ForeColor = System.Drawing.Color.White;
			this.label23.Location = new System.Drawing.Point(13, 33);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(539, 40);
			this.label23.TabIndex = 138;
			this.label23.Text = "Na prova de História, são cobrados fatos importantes do Brasil e do mundo, analis" +
	"ando contextos, causas e consequências, reflexão sobre o passado e o presente.";
			// 
			// label25
			// 
			this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label25.ForeColor = System.Drawing.Color.White;
			this.label25.Location = new System.Drawing.Point(150, 3);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(512, 39);
			this.label25.TabIndex = 137;
			this.label25.Text = "→ 1 resumo, 1 quiz";
			this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label26
			// 
			this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label26.ForeColor = System.Drawing.Color.White;
			this.label26.Location = new System.Drawing.Point(13, 2);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(662, 39);
			this.label26.TabIndex = 136;
			this.label26.Text = "MATEMÁTICA";
			this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.Maroon;
			this.panel3.Controls.Add(this.btnQuizPort);
			this.panel3.Controls.Add(this.btnResumoPort);
			this.panel3.Controls.Add(this.label5);
			this.panel3.Controls.Add(this.label4);
			this.panel3.Controls.Add(this.label3);
			this.panel3.Location = new System.Drawing.Point(12, 80);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(662, 76);
			this.panel3.TabIndex = 135;
			// 
			// btnQuizPort
			// 
			this.btnQuizPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnQuizPort.ForeColor = System.Drawing.Color.Maroon;
			this.btnQuizPort.Location = new System.Drawing.Point(558, 44);
			this.btnQuizPort.Name = "btnQuizPort";
			this.btnQuizPort.Size = new System.Drawing.Size(98, 23);
			this.btnQuizPort.TabIndex = 140;
			this.btnQuizPort.Text = "QUIZZES";
			this.btnQuizPort.UseVisualStyleBackColor = true;
			this.btnQuizPort.Click += new System.EventHandler(this.BtnQuizPortClick);
			// 
			// btnResumoPort
			// 
			this.btnResumoPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnResumoPort.ForeColor = System.Drawing.Color.Maroon;
			this.btnResumoPort.Location = new System.Drawing.Point(558, 12);
			this.btnResumoPort.Name = "btnResumoPort";
			this.btnResumoPort.Size = new System.Drawing.Size(98, 23);
			this.btnResumoPort.TabIndex = 139;
			this.btnResumoPort.Text = "RESUMOS";
			this.btnResumoPort.UseVisualStyleBackColor = true;
			this.btnResumoPort.Click += new System.EventHandler(this.BtnResumoPortClick);
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.White;
			this.label5.Location = new System.Drawing.Point(13, 33);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(539, 40);
			this.label5.TabIndex = 138;
			this.label5.Text = "Em Português, o foco está na leitura e interpretação de textos, além de questões " +
	"sobre gramática e produção de texto, testando a capacidade de compreender e se c" +
	"omunicar.";
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.White;
			this.label4.Location = new System.Drawing.Point(150, 3);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(307, 39);
			this.label4.TabIndex = 137;
			this.label4.Text = "→ 1 resumo, 1 quiz";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.White;
			this.label3.Location = new System.Drawing.Point(13, 2);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(662, 39);
			this.label3.TabIndex = 136;
			this.label3.Text = "PORTUGUÊS";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(50, 42);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(624, 25);
			this.label2.TabIndex = 134;
			this.label2.Text = "Cada página das matérias a seguir irão conter quizzes e resumos inspirados em tod" +
	"os os vestibulares anteriores.";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(72, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(561, 29);
			this.label1.TabIndex = 133;
			this.label1.Text = "MATÉRIAS PROVÃO PAULISTA";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// MateriasPVForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(877, 505);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.panel2);
			this.Name = "MateriasPVForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "MateriasPVForm";
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.panel2.ResumeLayout(false);
			this.panel10.ResumeLayout(false);
			this.panel9.ResumeLayout(false);
			this.panel7.ResumeLayout(false);
			this.panel6.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.panel8.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.ResumeLayout(false);

		}
	}
}
