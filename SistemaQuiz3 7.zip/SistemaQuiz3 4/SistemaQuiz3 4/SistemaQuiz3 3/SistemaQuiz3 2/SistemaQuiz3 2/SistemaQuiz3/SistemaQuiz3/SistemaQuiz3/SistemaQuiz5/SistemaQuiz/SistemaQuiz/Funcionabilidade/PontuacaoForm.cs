﻿/*
 * Created by SharpDevelop.
 * User: jenni
 * Date: 04/10/2025
 * Time: 21:17
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace SistemaQuiz
{
	/// <summary>
	/// Description of PontuacaoForm.
	/// </summary>
	public partial class PontuacaoForm : Form
	{
		public PontuacaoForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		string arquivo = "pontuacoes.txt";
		void MainFormLoad(object sender, EventArgs e)
		{
			string[] linhas = File.ReadAllLines(arquivo); 
            int qtd = linhas.Length;             

            string[] nomes = new string[qtd];    
            int[] pontos = new int[qtd];         
            int contador = 0;    

			foreach (string linha in linhas)     
            {
                string[] partes = linha.Split(',');

                if (partes.Length == 2)          
                {
                    string nome = partes[0].Trim(); 
					int valor;                     

                    if (int.TryParse(partes[1].Trim(), out valor)) 
                    {
                        nomes[contador] = nome;       
                        pontos[contador] = valor;    
                        contador++;                  
                    }
                }
			}
			
			for (int i = 0; i < contador - 1; i++)   
            {
                for (int j = i + 1; j < contador; j++) 
                {
                    if (pontos[j] > pontos[i])     
                    {
                        int tempPontos = pontos[i]; 
                        pontos[i] = pontos[j];      
                        pontos[j] = tempPontos;   
                        
                        string tempNome = nomes[i];
                        nomes[i] = nomes[j];        
                        nomes[j] = tempNome;      
                    }
                }
            }
			
lblNome1.Text = nomes[0].ToString();

            lblPontos1.Text = pontos[0].ToString();

            lblNome2.Text = nomes[1].ToString();

            lblPontos2.Text = pontos[1].ToString();

            lblNome3.Text = nomes[2].ToString();

            lblPontos3.Text = pontos[2].ToString();

            lblNome4.Text = nomes[3].ToString();

            lblPontos4.Text = pontos[3].ToString();

            lblNome5.Text = nomes[4].ToString();

            lblPontos5.Text = pontos[4].ToString();
 
			
		}
        
        void LblAssinaturasClick(object sender, EventArgs e)
        {
            AssinaturasForm assinaturasForm = new AssinaturasForm();
            assinaturasForm.Show();
            this.Hide();
        }
        void LblCursosUSPClick(object sender, EventArgs e)
        {

            CursosUSPForm cursosuspForm = new CursosUSPForm();
            cursosuspForm.Show();
            this.Hide();
        }
        void LblInfoUnespClick(object sender, EventArgs e)
        {

            InformacoesUnespForm informacoesunespForm = new InformacoesUnespForm();
            informacoesunespForm.Show();
            this.Hide();
        }
        void LblCursosUnespClick(object sender, EventArgs e)
        {
      
            CursosUnespForm cursosunespForm = new CursosUnespForm();
            cursosunespForm.Show();
            this.Hide();
        }
        void LblInfoUnicampClick(object sender, EventArgs e)
        {
       
            InformacoesUnicampForm informacoesunicampForm = new InformacoesUnicampForm();
            informacoesunicampForm.Show();
            this.Hide();
        }
        void LblCursosUnicampClick(object sender, EventArgs e)
        {
     
            CursosUnicampForm cursosunicampForm = new CursosUnicampForm();
            cursosunicampForm.Show();
            this.Hide();
        }
        void LblInfoFatecClick(object sender, EventArgs e)
        {
      
            InformacoesFatecForm informacoesfatecForm = new InformacoesFatecForm();
            informacoesfatecForm.Show();
            this.Hide();
        }
        void LblCursosFatecClick(object sender, EventArgs e)
        {

            CursosFatecForm cursosfatecForm = new CursosFatecForm();
            cursosfatecForm.Show();
            this.Hide();
        }
        void LblMateriasClick(object sender, EventArgs e)
        {

            MateriasPVForm materiaspvForm = new MateriasPVForm();
            materiaspvForm.Show();
            this.Hide();
        }
        void LblInicioClick(object sender, EventArgs e)
        {
            HomeForm homeForm = new HomeForm();
            homeForm.Show();
            this.Hide();
        }
        void Label23Click(object sender, EventArgs e)
        {
            VestibularesForm vestibularesForm = new VestibularesForm();
            vestibularesForm.Show();
            this.Hide();
        }
        
        void LblHomeClick(object sender, EventArgs e)
        {
            HomeForm homeForm = new HomeForm();
            homeForm.Show();
            this.Hide();        
        }

         void LblInfoUSPClick(object sender, EventArgs e)
        {
            InformacoesUSPForm informacoesuspForm = new InformacoesUSPForm();
            informacoesuspForm.Show();
            this.Hide();
        }
	}
}
