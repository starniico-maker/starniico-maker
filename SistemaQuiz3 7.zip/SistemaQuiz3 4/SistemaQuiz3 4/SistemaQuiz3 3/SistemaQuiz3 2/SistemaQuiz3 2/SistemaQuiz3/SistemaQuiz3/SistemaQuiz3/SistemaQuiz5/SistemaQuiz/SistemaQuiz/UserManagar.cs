﻿/*
 * Created by SharpDevelop.
 * User: jenni
 * Date: 28/09/2025
 * Time: 22:20
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.Collections.Generic;
using System.IO;

namespace SistemQuiz
{
    public static class UserManager
    {
        private static string arquivoUsuarios = "usuarios.txt";
        private static List<Usuario> usuariosCadastrados = new List<Usuario>();

        
        static UserManager()
        {
            CarregarUsuarios();
        }

        public static List<Usuario> UsuariosCadastrados 
        { 
            get { return usuariosCadastrados; } 
        }

        public static void AdicionarUsuario(Usuario usuario)
        {
            usuariosCadastrados.Add(usuario);
            SalvarUsuarioNoArquivo(usuario);
        }

        public static bool VerificarLogin(string nomeUsuario, string senha)
        {
        	
            foreach (Usuario usuario in usuariosCadastrados)
            	
            {
                if (usuario.NomeUsuario == nomeUsuario && usuario.Senha == senha)
                {
                    return true;
                }
            }

            return VerificarLoginNoArquivo(nomeUsuario, senha);
        }

        public static bool UsuarioExiste(string nomeUsuario)
        {
            foreach (Usuario usuario in usuariosCadastrados)
            {
                if (usuario.NomeUsuario == nomeUsuario)
                {
                    return true;
                }
            }
            return false;
        }

        private static void CarregarUsuarios()
        {
            if (File.Exists(arquivoUsuarios))
            {
                try
                {
                    usuariosCadastrados.Clear();
                    foreach (string linha in File.ReadAllLines(arquivoUsuarios))
                    {
                        string[] dados = linha.Split(';');
                        if (dados.Length >= 3)
                        {
                            Usuario usuario = new Usuario(dados[0], dados[0], dados[1], dados[2]);
                            usuariosCadastrados.Add(usuario);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro ao carregar usuários: " + ex.Message);
                }
            }
        }

        private static bool VerificarLoginNoArquivo(string nomeUsuario, string senha)
        {
            if (File.Exists(arquivoUsuarios))
            {
                foreach (string linha in File.ReadAllLines(arquivoUsuarios))
                {
                    string[] dados = linha.Split(';');
                    if (dados.Length >= 3 && dados[0] == nomeUsuario && dados[1] == senha)
                    {
      
                        Usuario usuario = new Usuario(dados[0], dados[0], dados[1], dados[2]);
                        if (!UsuarioExiste(nomeUsuario))
                        {
                            usuariosCadastrados.Add(usuario);
                        }
                        return true;
                    }
                }
            }
            return false;
        }

        private static void SalvarUsuarioNoArquivo(Usuario usuario)
        {
            try
            {
                using (StreamWriter sw = File.AppendText(arquivoUsuarios))
                {
                    sw.WriteLine(usuario.NomeUsuario + ";" + usuario.Senha + ";" + usuario.Email);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao salvar usuário: " + ex.Message);
            }
        }
    }

    public class Usuario
    {
        public string NomeCompleto { get; set; }
        public string NomeUsuario { get; set; }
        public string Senha { get; set; }
        public string Email { get; set; }

        public Usuario(string nomeCompleto, string nomeUsuario, string senha, string email)
        {
            NomeCompleto = nomeCompleto;
            NomeUsuario = nomeUsuario;
            Senha = senha;
            Email = email;
       }
    }
}
