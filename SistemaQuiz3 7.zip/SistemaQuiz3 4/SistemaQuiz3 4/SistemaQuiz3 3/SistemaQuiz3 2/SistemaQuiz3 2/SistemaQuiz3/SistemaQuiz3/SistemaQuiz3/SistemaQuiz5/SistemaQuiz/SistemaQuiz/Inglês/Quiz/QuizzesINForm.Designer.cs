﻿/*
 * Created by SharpDevelop.
 * User: jenni
 * Date: 19/10/2025
 * Time: 19:52
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace SistemaQuiz
{
	partial class QuizzesINForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label lblAssinaturas;
		private System.Windows.Forms.Label lblPontuacao;
		private System.Windows.Forms.Label lblHome;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label lblMaterias;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label lblInfoUSP;
		private System.Windows.Forms.Label lblCursosUSP;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label lblInfoUnesp;
		private System.Windows.Forms.Label lblCursosUnesp;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label lblInfoUnicamp;
		private System.Windows.Forms.Label lblCursosUnicamp;
		private System.Windows.Forms.Label lblFatec;
		private System.Windows.Forms.Label lblInfoFatec;
		private System.Windows.Forms.Label lblCursosFatec;
		private System.Windows.Forms.Label lblVestibulares;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btnQuiz1;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label6;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuizzesINForm));
			this.panel1 = new System.Windows.Forms.Panel();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.lblAssinaturas = new System.Windows.Forms.Label();
			this.lblPontuacao = new System.Windows.Forms.Label();
			this.lblHome = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.lblMaterias = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.lblInfoUSP = new System.Windows.Forms.Label();
			this.lblCursosUSP = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.lblInfoUnesp = new System.Windows.Forms.Label();
			this.lblCursosUnesp = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.lblInfoUnicamp = new System.Windows.Forms.Label();
			this.lblCursosUnicamp = new System.Windows.Forms.Label();
			this.lblFatec = new System.Windows.Forms.Label();
			this.lblInfoFatec = new System.Windows.Forms.Label();
			this.lblCursosFatec = new System.Windows.Forms.Label();
			this.lblVestibulares = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.label3 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.panel8 = new System.Windows.Forms.Panel();
			this.label4 = new System.Windows.Forms.Label();
			this.btnQuiz1 = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.panel2.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel8.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.DarkRed;
			this.panel1.Controls.Add(this.pictureBox1);
			this.panel1.Controls.Add(this.lblAssinaturas);
			this.panel1.Controls.Add(this.lblPontuacao);
			this.panel1.Controls.Add(this.lblHome);
			this.panel1.Controls.Add(this.label24);
			this.panel1.Controls.Add(this.label20);
			this.panel1.Controls.Add(this.lblMaterias);
			this.panel1.Controls.Add(this.label17);
			this.panel1.Controls.Add(this.lblInfoUSP);
			this.panel1.Controls.Add(this.lblCursosUSP);
			this.panel1.Controls.Add(this.label14);
			this.panel1.Controls.Add(this.lblInfoUnesp);
			this.panel1.Controls.Add(this.lblCursosUnesp);
			this.panel1.Controls.Add(this.label11);
			this.panel1.Controls.Add(this.lblInfoUnicamp);
			this.panel1.Controls.Add(this.lblCursosUnicamp);
			this.panel1.Controls.Add(this.lblFatec);
			this.panel1.Controls.Add(this.lblInfoFatec);
			this.panel1.Controls.Add(this.lblCursosFatec);
			this.panel1.Controls.Add(this.lblVestibulares);
			this.panel1.Controls.Add(this.label7);
			this.panel1.ForeColor = System.Drawing.Color.Transparent;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(169, 512);
			this.panel1.TabIndex = 144;
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(25, 0);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(101, 64);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 33;
			this.pictureBox1.TabStop = false;
			// 
			// lblAssinaturas
			// 
			this.lblAssinaturas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAssinaturas.Location = new System.Drawing.Point(13, 110);
			this.lblAssinaturas.Name = "lblAssinaturas";
			this.lblAssinaturas.Size = new System.Drawing.Size(131, 23);
			this.lblAssinaturas.TabIndex = 32;
			this.lblAssinaturas.Text = "Assinaturas";
			this.lblAssinaturas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblAssinaturas.Click += new System.EventHandler(this.LblAssinaturasClick);
			// 
			// lblPontuacao
			// 
			this.lblPontuacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPontuacao.Location = new System.Drawing.Point(13, 87);
			this.lblPontuacao.Name = "lblPontuacao";
			this.lblPontuacao.Size = new System.Drawing.Size(131, 23);
			this.lblPontuacao.TabIndex = 31;
			this.lblPontuacao.Text = "Pontuação";
			this.lblPontuacao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblPontuacao.Click += new System.EventHandler(this.LblPontuacaoClick);
			// 
			// lblHome
			// 
			this.lblHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblHome.Location = new System.Drawing.Point(25, 64);
			this.lblHome.Name = "lblHome";
			this.lblHome.Size = new System.Drawing.Size(119, 23);
			this.lblHome.TabIndex = 24;
			this.lblHome.Text = "Tela Inicial";
			this.lblHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblHome.Click += new System.EventHandler(this.LblHomeClick);
			// 
			// label24
			// 
			this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label24.Location = new System.Drawing.Point(3, 63);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(29, 23);
			this.label24.TabIndex = 23;
			this.label24.Text = "➔ ";
			this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label20
			// 
			this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label20.Location = new System.Drawing.Point(13, 164);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(145, 23);
			this.label20.TabIndex = 29;
			this.label20.Text = "Provão Paulista";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblMaterias
			// 
			this.lblMaterias.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblMaterias.Location = new System.Drawing.Point(13, 184);
			this.lblMaterias.Name = "lblMaterias";
			this.lblMaterias.Size = new System.Drawing.Size(107, 23);
			this.lblMaterias.TabIndex = 30;
			this.lblMaterias.Text = "• Matérias";
			this.lblMaterias.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblMaterias.Click += new System.EventHandler(this.LblMateriasClick);
			// 
			// label17
			// 
			this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label17.Location = new System.Drawing.Point(13, 215);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(107, 23);
			this.label17.TabIndex = 26;
			this.label17.Text = "USP";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblInfoUSP
			// 
			this.lblInfoUSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoUSP.Location = new System.Drawing.Point(13, 238);
			this.lblInfoUSP.Name = "lblInfoUSP";
			this.lblInfoUSP.Size = new System.Drawing.Size(145, 23);
			this.lblInfoUSP.TabIndex = 27;
			this.lblInfoUSP.Text = "• Informações";
			this.lblInfoUSP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoUSP.Click += new System.EventHandler(this.LblInfoUSPClick);
			// 
			// lblCursosUSP
			// 
			this.lblCursosUSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosUSP.Location = new System.Drawing.Point(13, 254);
			this.lblCursosUSP.Name = "lblCursosUSP";
			this.lblCursosUSP.Size = new System.Drawing.Size(107, 24);
			this.lblCursosUSP.TabIndex = 28;
			this.lblCursosUSP.Text = "• Cursos";
			this.lblCursosUSP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosUSP.Click += new System.EventHandler(this.LblCursosUSPClick);
			// 
			// label14
			// 
			this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.Location = new System.Drawing.Point(13, 286);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(107, 23);
			this.label14.TabIndex = 23;
			this.label14.Text = "Unesp";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblInfoUnesp
			// 
			this.lblInfoUnesp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoUnesp.Location = new System.Drawing.Point(13, 307);
			this.lblInfoUnesp.Name = "lblInfoUnesp";
			this.lblInfoUnesp.Size = new System.Drawing.Size(107, 23);
			this.lblInfoUnesp.TabIndex = 24;
			this.lblInfoUnesp.Text = "• Informações";
			this.lblInfoUnesp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoUnesp.Click += new System.EventHandler(this.LblInfoUnespClick);
			// 
			// lblCursosUnesp
			// 
			this.lblCursosUnesp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosUnesp.Location = new System.Drawing.Point(13, 323);
			this.lblCursosUnesp.Name = "lblCursosUnesp";
			this.lblCursosUnesp.Size = new System.Drawing.Size(107, 24);
			this.lblCursosUnesp.TabIndex = 25;
			this.lblCursosUnesp.Text = "• Cursos";
			this.lblCursosUnesp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosUnesp.Click += new System.EventHandler(this.LblCursosUnespClick);
			// 
			// label11
			// 
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.Location = new System.Drawing.Point(13, 358);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(107, 23);
			this.label11.TabIndex = 20;
			this.label11.Text = "Unicamp";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblInfoUnicamp
			// 
			this.lblInfoUnicamp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoUnicamp.Location = new System.Drawing.Point(13, 378);
			this.lblInfoUnicamp.Name = "lblInfoUnicamp";
			this.lblInfoUnicamp.Size = new System.Drawing.Size(107, 23);
			this.lblInfoUnicamp.TabIndex = 21;
			this.lblInfoUnicamp.Text = "• Informações";
			this.lblInfoUnicamp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoUnicamp.Click += new System.EventHandler(this.LblInfoUnicampClick);
			// 
			// lblCursosUnicamp
			// 
			this.lblCursosUnicamp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosUnicamp.Location = new System.Drawing.Point(13, 394);
			this.lblCursosUnicamp.Name = "lblCursosUnicamp";
			this.lblCursosUnicamp.Size = new System.Drawing.Size(107, 24);
			this.lblCursosUnicamp.TabIndex = 22;
			this.lblCursosUnicamp.Text = "• Cursos";
			this.lblCursosUnicamp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosUnicamp.Click += new System.EventHandler(this.LblCursosUnicampClick);
			// 
			// lblFatec
			// 
			this.lblFatec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFatec.Location = new System.Drawing.Point(13, 427);
			this.lblFatec.Name = "lblFatec";
			this.lblFatec.Size = new System.Drawing.Size(107, 23);
			this.lblFatec.TabIndex = 17;
			this.lblFatec.Text = "Fatec";
			this.lblFatec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblInfoFatec
			// 
			this.lblInfoFatec.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInfoFatec.Location = new System.Drawing.Point(13, 447);
			this.lblInfoFatec.Name = "lblInfoFatec";
			this.lblInfoFatec.Size = new System.Drawing.Size(107, 23);
			this.lblInfoFatec.TabIndex = 18;
			this.lblInfoFatec.Text = "• Informações";
			this.lblInfoFatec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblInfoFatec.Click += new System.EventHandler(this.LblInfoFatecClick);
			// 
			// lblCursosFatec
			// 
			this.lblCursosFatec.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCursosFatec.Location = new System.Drawing.Point(13, 463);
			this.lblCursosFatec.Name = "lblCursosFatec";
			this.lblCursosFatec.Size = new System.Drawing.Size(107, 24);
			this.lblCursosFatec.TabIndex = 19;
			this.lblCursosFatec.Text = "• Cursos";
			this.lblCursosFatec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblCursosFatec.Click += new System.EventHandler(this.LblCursosFatecClick);
			// 
			// lblVestibulares
			// 
			this.lblVestibulares.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblVestibulares.Location = new System.Drawing.Point(25, 140);
			this.lblVestibulares.Name = "lblVestibulares";
			this.lblVestibulares.Size = new System.Drawing.Size(119, 23);
			this.lblVestibulares.TabIndex = 7;
			this.lblVestibulares.Text = "Vestibulares";
			this.lblVestibulares.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.Location = new System.Drawing.Point(3, 139);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(29, 23);
			this.label7.TabIndex = 6;
			this.label7.Text = "➔ ";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.panel3);
			this.panel2.Controls.Add(this.label2);
			this.panel2.Controls.Add(this.label1);
			this.panel2.Controls.Add(this.panel8);
			this.panel2.Location = new System.Drawing.Point(175, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(702, 512);
			this.panel2.TabIndex = 145;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.DarkGray;
			this.panel3.Controls.Add(this.label3);
			this.panel3.Controls.Add(this.label6);
			this.panel3.Location = new System.Drawing.Point(12, 215);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(678, 106);
			this.panel3.TabIndex = 145;
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.White;
			this.label3.Location = new System.Drawing.Point(14, 50);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(649, 56);
			this.label3.TabIndex = 139;
			this.label3.Text = "Quiz disponível em breve.";
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.White;
			this.label6.Location = new System.Drawing.Point(13, 0);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(662, 39);
			this.label6.TabIndex = 137;
			this.label6.Text = "QUIZ 2";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(3, 47);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(696, 39);
			this.label2.TabIndex = 134;
			this.label2.Text = "Possuímos 1 quiz sobre Inglês, composto por 5\r\nperguntas. Cada pergunta vale por " +
	"1 ponto.";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(3, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(696, 39);
			this.label1.TabIndex = 133;
			this.label1.Text = "QUIZ DE INGLÊS";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel8
			// 
			this.panel8.BackColor = System.Drawing.Color.Maroon;
			this.panel8.Controls.Add(this.label4);
			this.panel8.Controls.Add(this.btnQuiz1);
			this.panel8.Controls.Add(this.label5);
			this.panel8.Controls.Add(this.label8);
			this.panel8.Location = new System.Drawing.Point(12, 101);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(678, 106);
			this.panel8.TabIndex = 143;
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.White;
			this.label4.Location = new System.Drawing.Point(88, 5);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(470, 39);
			this.label4.TabIndex = 140;
			this.label4.Text = "→ 5 perguntas";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// btnQuiz1
			// 
			this.btnQuiz1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnQuiz1.ForeColor = System.Drawing.Color.Maroon;
			this.btnQuiz1.Location = new System.Drawing.Point(564, 11);
			this.btnQuiz1.Name = "btnQuiz1";
			this.btnQuiz1.Size = new System.Drawing.Size(98, 27);
			this.btnQuiz1.TabIndex = 139;
			this.btnQuiz1.Text = "ACESSAR";
			this.btnQuiz1.UseVisualStyleBackColor = true;
			this.btnQuiz1.Click += new System.EventHandler(this.BtnQuiz1Click);
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.White;
			this.label5.Location = new System.Drawing.Point(13, 41);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(649, 67);
			this.label5.TabIndex = 138;
			this.label5.Text = "TEMA: Interpretação de texto\r\n\r\nCONTEÚDO: Vocabulário.\r\n\r\n";
			// 
			// label8
			// 
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.ForeColor = System.Drawing.Color.White;
			this.label8.Location = new System.Drawing.Point(13, 3);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(662, 39);
			this.label8.TabIndex = 136;
			this.label8.Text = "QUIZ 1";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// QuizzesINForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(877, 512);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.panel2);
			this.Name = "QuizzesINForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "QuizzesINForm";
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.panel2.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.panel8.ResumeLayout(false);
			this.ResumeLayout(false);

		}
	}
}
