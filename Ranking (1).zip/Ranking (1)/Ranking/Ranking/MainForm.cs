﻿/*
 * Created by SharpDevelop.
 * User: 20252930077
 * Date: 17/11/2025
 * Time: 13:16
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace Ranking
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		string arquivo = "pontuacoes.txt";
		void MainFormLoad(object sender, EventArgs e)
		{
			string[] linhas = File.ReadAllLines(arquivo); 
            int qtd = linhas.Length;             

            string[] nomes = new string[qtd];    
            int[] pontos = new int[qtd];         
            int contador = 0;    

			foreach (string linha in linhas)     
            {
                string[] partes = linha.Split(','); // Divide a linha na vírgula, resultando em partes[0]=nome, partes[1]=pontos.

                if (partes.Length == 2)          // Verifica se a linha tem exatamente duas partes (evita linhas malformadas).
                {
                    string nome = partes[0].Trim();  // Remove espaços antes/depois do nome.
                    int valor;                        // Declara variável para armazenar a conversão para int.

                    if (int.TryParse(partes[1].Trim(), out valor)) // Tenta converter a segunda parte para inteiro.
                    {
                        nomes[contador] = nome;       // Se conversão ok, armazena o nome no array 'nomes' na posição 'contador'.
                        pontos[contador] = valor;    // Armazena a pontuação no array 'pontos' na mesma posição.
                        contador++;                  // Incrementa o contador de registros válidos.
                    }
                    // Se a conversão falhar, a linha é ignorada (não incrementamos contador).
                }
			}
			
			for (int i = 0; i < contador - 1; i++)   // Primeiro laço percorre as posições do array até penúltima válida.
            {
                for (int j = i + 1; j < contador; j++) // Segundo laço compara a posição i com todas as posições seguintes j.
                {
                    if (pontos[j] > pontos[i])      // Se o elemento na posição j tem mais pontos que o da posição i...
                    {
                        int tempPontos = pontos[i]; // ...armazena temporariamente pontos[i]
                        pontos[i] = pontos[j];      // coloca pontos[j] em pontos[i]
                        pontos[j] = tempPontos;     // e restaura o valor temporário em pontos[j]

                        string tempNome = nomes[i]; // Faz a mesma troca para o array de nomes (troca paralela).
                        nomes[i] = nomes[j];        // Coloca nomes[j] em nomes[i]
                        nomes[j] = tempNome;       // Restaura o nome temporário em nomes[j]
                    }
                }
            }
			
			lblNome1.Text = nomes[0].ToString();
			lblPontos1.Text = pontos[0].ToString();
			lblNome2.Text = nomes[1].ToString();
			lblPontos2.Text = pontos[1].ToString();
			
		}
	}
}
